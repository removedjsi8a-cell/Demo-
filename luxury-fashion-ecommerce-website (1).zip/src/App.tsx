import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ShopProvider } from './context/ShopContext';
import MainLayout from './components/layout/MainLayout';
import ScrollToTop from './components/utils/ScrollToTop';

// Pages
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetails from './pages/ProductDetails';
import Checkout from './pages/Checkout';
import OrderSuccess from './pages/OrderSuccess';
import AdminDashboard from './pages/admin/AdminDashboard';

// Placeholder Pages
const About = () => <div className="py-20 container mx-auto px-6"><h1 className="text-4xl font-serif">About Us</h1><p className="mt-8 text-zinc-500 max-w-2xl">LUMIÈRE was founded on the principles of absolute quality and timeless design. Our mission is to bridge the gap between artisanal craftsmanship and modern luxury.</p></div>;
const Contact = () => <div className="py-20 container mx-auto px-6"><h1 className="text-4xl font-serif">Contact Us</h1><p className="mt-8 text-zinc-500">Email: concierge@lumiere.com<br/>Phone: +33 1 23 45 67 89</p></div>;
const Wishlist = () => <div className="py-20 container mx-auto px-6"><h1 className="text-4xl font-serif">Your Wishlist</h1><p className="mt-8 text-zinc-500">Curate your perfect wardrobe. Your saved items will appear here.</p></div>;
const Account = () => <div className="py-20 container mx-auto px-6"><h1 className="text-4xl font-serif">My Account</h1><div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8"><div className="p-6 border border-zinc-100 bg-zinc-50">Order History</div><div className="p-6 border border-zinc-100 bg-zinc-50">Addresses</div><div className="p-6 border border-zinc-100 bg-zinc-50">Loyalty Program</div></div></div>;

const App = () => {
  return (
    <ShopProvider>
      <Router>
        <ScrollToTop />
        <Routes>
          {/* Main Website Routes */}
          <Route path="/" element={<MainLayout><Home /></MainLayout>} />
          <Route path="/shop" element={<MainLayout><Shop /></MainLayout>} />
          <Route path="/product/:id" element={<MainLayout><ProductDetails /></MainLayout>} />
          <Route path="/checkout" element={<MainLayout><Checkout /></MainLayout>} />
          <Route path="/order-success" element={<MainLayout><OrderSuccess /></MainLayout>} />
          <Route path="/about" element={<MainLayout><About /></MainLayout>} />
          <Route path="/contact" element={<MainLayout><Contact /></MainLayout>} />
          <Route path="/wishlist" element={<MainLayout><Wishlist /></MainLayout>} />
          <Route path="/account" element={<MainLayout><Account /></MainLayout>} />
          <Route path="/collections" element={<MainLayout><Shop /></MainLayout>} />
          <Route path="/new-arrivals" element={<MainLayout><Shop /></MainLayout>} />
          <Route path="/best-sellers" element={<MainLayout><Shop /></MainLayout>} />
          <Route path="/tracking" element={<MainLayout><div className="py-20 container mx-auto px-6 font-serif text-3xl">Track Your Order</div></MainLayout>} />
          <Route path="/faq" element={<MainLayout><div className="py-20 container mx-auto px-6 font-serif text-3xl">FAQs</div></MainLayout>} />
          <Route path="/privacy" element={<MainLayout><div className="py-20 container mx-auto px-6 font-serif text-3xl">Privacy Policy</div></MainLayout>} />
          <Route path="/terms" element={<MainLayout><div className="py-20 container mx-auto px-6 font-serif text-3xl">Terms & Conditions</div></MainLayout>} />
          <Route path="/shipping-returns" element={<MainLayout><div className="py-20 container mx-auto px-6 font-serif text-3xl">Shipping & Returns</div></MainLayout>} />

          {/* Admin Routes */}
          <Route path="/admin" element={<AdminDashboard />} />
        </Routes>
      </Router>
    </ShopProvider>
  );
};

export default App;
