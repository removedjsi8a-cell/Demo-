import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Plus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useShop } from '../../context/ShopContext';
import { Link } from 'react-router-dom';

const CartDrawer = () => {
  const { cart, isCartOpen, setIsCartOpen, updateCartQuantity, removeFromCart } = useShop();

  const subtotal = cart.reduce((acc, item) => acc + (item.discountPrice || item.price) * item.quantity, 0);

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[70]"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-sm bg-white z-[80] shadow-2xl flex flex-col"
          >
            <div className="p-6 flex justify-between items-center border-b border-zinc-100">
              <div className="flex items-center space-x-2">
                <ShoppingBag className="w-5 h-5" />
                <h2 className="text-xl font-serif uppercase tracking-widest">Bag ({cart.length})</h2>
              </div>
              <button onClick={() => setIsCartOpen(false)} className="hover:rotate-90 transition-transform duration-300 p-2">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-grow overflow-y-auto p-6 space-y-6 no-scrollbar">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                  <div className="w-16 h-16 bg-zinc-50 rounded-full flex items-center justify-center mb-4">
                    <ShoppingBag className="w-6 h-6 text-zinc-300" />
                  </div>
                  <p className="text-zinc-500 font-serif text-base uppercase tracking-widest">Empty Bag</p>
                  <Link 
                    to="/shop" 
                    onClick={() => setIsCartOpen(false)}
                    className="luxury-button-outline text-[10px] uppercase py-3"
                  >
                    Explore Shop
                  </Link>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={`${item.id}-${item.selectedSize}-${item.selectedColor}`} className="flex space-x-4">
                    <div className="w-20 h-24 bg-zinc-100 flex-shrink-0 overflow-hidden">
                      <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-grow flex flex-col">
                      <div className="flex justify-between items-start">
                        <h3 className="text-[10px] font-bold uppercase tracking-widest max-w-[120px]">{item.name}</h3>
                        <button 
                          onClick={() => removeFromCart(item.id, item.selectedSize, item.selectedColor)}
                          className="text-zinc-400 hover:text-black transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[8px] text-zinc-400 mt-1 uppercase tracking-tighter">
                        {item.selectedSize} | {item.selectedColor}
                      </p>
                      <div className="mt-auto flex justify-between items-end">
                        <div className="flex items-center border border-zinc-100 bg-zinc-50">
                          <button 
                            onClick={() => updateCartQuantity(item.id, item.selectedSize, item.selectedColor, item.quantity - 1)}
                            className="p-1 hover:text-accent"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-3 text-[10px] font-bold">{item.quantity}</span>
                          <button 
                            onClick={() => updateCartQuantity(item.id, item.selectedSize, item.selectedColor, item.quantity + 1)}
                            className="p-1 hover:text-accent"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <p className="font-bold text-[11px]">
                          ₹{((item.discountPrice || item.price) * item.quantity).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 bg-white border-t border-zinc-100">
                <div className="flex justify-between mb-4">
                  <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Estimated Total</span>
                  <span className="text-lg font-serif">₹{subtotal.toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-1 gap-3">
                  <Link 
                    to="/checkout" 
                    onClick={() => setIsCartOpen(false)}
                    className="luxury-button text-[10px] uppercase flex items-center justify-center space-x-2 py-4"
                  >
                    <span>Secure Checkout</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                  <Link 
                    to="/cart" 
                    onClick={() => setIsCartOpen(false)}
                    className="text-center text-[10px] uppercase font-bold text-zinc-400 hover:text-black transition-colors"
                  >
                    View Shopping Bag
                  </Link>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;
