import React from 'react';
import { motion } from 'framer-motion';

const AnnouncementBar = () => {
  return (
    <div className="bg-black text-white py-1 overflow-hidden relative z-50">
      <motion.div
        animate={{ x: [0, -1000] }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        className="whitespace-nowrap flex space-x-20 items-center"
      >
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">Flat 50% OFF on Selected Items</span>
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">Free Shipping on Orders Above ₹399</span>
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">New Arrivals: Indian Ethnic Special</span>
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">Shop the Latest SS24 Collection</span>
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">Flat 50% OFF on Selected Items</span>
        <span className="text-[8px] uppercase tracking-[0.2em] font-bold">Free Shipping on Orders Above ₹399</span>
      </motion.div>
    </div>
  );
};

export default AnnouncementBar;
