import React from 'react';
import { Globe, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-black text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Info */}
          <div>
            <h3 className="text-2xl font-serif tracking-widest mb-6">LUMIÈRE</h3>
            <p className="text-zinc-400 text-sm leading-relaxed mb-8 max-w-xs">
              Defining the future of luxury fashion through sustainable practices and timeless Italian craftsmanship.
            </p>
            <div className="flex space-x-5">
              <a href="#" className="hover:text-accent transition-colors"><Globe className="w-5 h-5" /></a>
              <a href="#" className="hover:text-accent transition-colors"><Globe className="w-5 h-5" /></a>
              <a href="#" className="hover:text-accent transition-colors"><Globe className="w-5 h-5" /></a>
              <a href="#" className="hover:text-accent transition-colors"><Globe className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="text-sm uppercase tracking-widest mb-6">Collections</h4>
            <ul className="space-y-4 text-sm text-zinc-400">
              <li><Link to="/shop?category=Men" className="hover:text-white transition-colors">Men's Wear</Link></li>
              <li><Link to="/shop?category=Women" className="hover:text-white transition-colors">Women's Wear</Link></li>
              <li><Link to="/shop?category=Accessories" className="hover:text-white transition-colors">Accessories</Link></li>
              <li><Link to="/new-arrivals" className="hover:text-white transition-colors">New Arrivals</Link></li>
              <li><Link to="/best-sellers" className="hover:text-white transition-colors">Best Sellers</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="text-sm uppercase tracking-widest mb-6">Customer Service</h4>
            <ul className="space-y-4 text-sm text-zinc-400">
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/tracking" className="hover:text-white transition-colors">Track Your Order</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">FAQs</Link></li>
              <li><Link to="/shipping-returns" className="hover:text-white transition-colors">Shipping & Returns</Link></li>
              <li><Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-sm uppercase tracking-widest mb-6">Join the Atelier</h4>
            <p className="text-zinc-400 text-sm mb-6">Subscribe to receive updates, access to exclusive deals, and more.</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="w-full bg-transparent border-b border-zinc-700 py-2 focus:outline-none focus:border-white transition-colors text-sm"
              />
              <button className="absolute right-0 bottom-2 hover:text-accent transition-colors">
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-zinc-800 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-widest text-zinc-500 space-y-6 md:space-y-0">
          <div className="flex flex-col space-y-2">
            <p>© 2024 LUMIÈRE Haute Couture. All rights reserved.</p>
            <div className="flex items-center space-x-2 text-zinc-400 font-bold">
              <span>Made by</span>
              <span className="text-accent uppercase">Dhivi</span>
              <span className="mx-2">|</span>
              <a href="https://wa.me/9566380359" className="hover:text-white transition-colors">Contact: 9566380359 (WhatsApp)</a>
            </div>
          </div>
          <div className="flex space-x-8">
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
