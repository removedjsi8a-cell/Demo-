import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import AnnouncementBar from './AnnouncementBar';
import CartDrawer from '../cart/CartDrawer';

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen w-full max-w-full overflow-x-hidden bg-white relative">
      <div className="sticky top-0 w-full z-50">
        <AnnouncementBar />
        <Navbar />
      </div>
      <main className="flex-grow w-full max-w-full">
        {children}
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
};

export default MainLayout;
