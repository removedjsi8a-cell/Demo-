import React from 'react';
import { ShoppingBag, Search, User, Heart, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useShop } from '../../context/ShopContext';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
  const { cart, wishlist, setIsCartOpen } = useShop();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isScrolled, setIsScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Men', path: '/shop?category=Men' },
    { name: 'Women', path: '/shop?category=Women' },
    { name: 'Collections', path: '/collections' },
    { name: 'About', path: '/about' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white py-3 shadow-sm' : 'bg-white/80 backdrop-blur-md py-4 shadow-sm'}`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <button className="lg:hidden p-2" onClick={() => setIsMobileMenuOpen(true)}>
          <Menu className="w-5 h-5" />
        </button>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center space-x-6">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} className="nav-link font-medium text-xs">
              {link.name}
            </Link>
          ))}
        </div>

        {/* Logo */}
        <Link to="/" className="absolute left-1/2 -translate-x-1/2 text-xl font-serif tracking-[0.2em] font-bold">
          LUMIÈRE
        </Link>

        {/* Icons */}
        <div className="flex items-center space-x-6">
          <button className="hidden sm:block hover:text-accent transition-colors">
            <Search className="w-5 h-5" />
          </button>
          <Link to="/account" className="hidden sm:block hover:text-accent transition-colors">
            <User className="w-5 h-5" />
          </Link>
          <Link to="/wishlist" className="relative hover:text-accent transition-colors">
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-accent text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </Link>
          <button onClick={() => setIsCartOpen(true)} className="relative hover:text-accent transition-colors">
            <ShoppingBag className="w-5 h-5" />
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                {cart.reduce((acc, item) => acc + item.quantity, 0)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="fixed inset-0 bg-white z-[60] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="text-2xl font-serif tracking-widest">LUMIÈRE</span>
              <button onClick={() => setIsMobileMenuOpen(false)}>
                <X className="w-8 h-8" />
              </button>
            </div>
            <div className="flex flex-col space-y-6">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-3xl font-serif hover:italic transition-all"
                >
                  {link.name}
                </Link>
              ))}
              <div className="pt-12 border-t border-zinc-100 flex flex-col space-y-4">
                <Link to="/account" className="text-lg">My Account</Link>
                <Link to="/tracking" className="text-lg">Track Order</Link>
                <Link to="/contact" className="text-lg">Contact Us</Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
