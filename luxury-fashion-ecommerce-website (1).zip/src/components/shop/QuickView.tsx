import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShoppingBag } from 'lucide-react';
import { Product } from '../../types';
import { useShop } from '../../context/ShopContext';

interface QuickViewProps {
  product: Product | null;
  onClose: () => void;
}

const QuickView: React.FC<QuickViewProps> = ({ product, onClose }) => {
  const { addToCart } = useShop();
  
  if (!product) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white w-full max-w-4xl overflow-hidden relative flex flex-col md:flex-row"
          onClick={e => e.stopPropagation()}
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 bg-white/80 hover:bg-white transition-colors rounded-full"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="md:w-1/2 aspect-[3/4] bg-zinc-100">
            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
          </div>

          <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
            <span className="text-[9px] uppercase tracking-[0.2em] text-zinc-400 mb-3 block">{product.subCategory}</span>
            <h2 className="text-2xl font-serif mb-3">{product.name}</h2>
            <p className="text-lg font-serif mb-4">${product.price.toLocaleString()}</p>
            <p className="text-zinc-500 text-xs leading-relaxed mb-6">{product.description}</p>
            
            <div className="space-y-6">
              <div className="flex space-x-4">
                <button 
                  onClick={() => {
                    addToCart(product, 1, product.sizes[0], product.colors[0].name);
                    onClose();
                  }}
                  className="flex-grow luxury-button flex items-center justify-center space-x-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Bag</span>
                </button>
              </div>
              <button 
                onClick={onClose}
                className="w-full text-[10px] uppercase tracking-widest text-zinc-400 hover:text-black transition-colors underline"
              >
                View Full Details
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default QuickView;
