import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronRight, CreditCard, ShieldCheck, Truck, ArrowLeft, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Checkout = () => {
  const { cart, clearCart } = useShop();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    zip: '',
    country: 'India'
  });

  const subtotal = cart.reduce((acc, item) => acc + (item.discountPrice || item.price) * item.quantity, 0);
  const [coupon, setCoupon] = useState('');
  const [discount, setDiscount] = useState(0);
  const [showCouponPopup, setShowCouponPopup] = useState(false);

  const shipping = subtotal > 5000 ? 0 : 100;
  const tax = subtotal * 0.12;
  const total = subtotal + shipping + tax - discount;

  const applyCoupon = () => {
    if (coupon.toUpperCase() === 'LUMI200') {
      setDiscount(200);
      setShowCouponPopup(true);
    } else {
      alert('Invalid Coupon Code');
    }
  };

  const handlePlaceOrder = () => {
    // Save order info to session for success page
    const orderDetails = {
      id: `ORD-${Math.floor(Math.random() * 90000) + 10000}`,
      total,
      items: cart,
      customer: formData,
      paymentMethod,
      date: new Date().toLocaleDateString()
    };
    sessionStorage.setItem('lastOrder', JSON.stringify(orderDetails));
    
    setTimeout(() => {
      clearCart();
      navigate('/order-success');
    }, 1500);
  };

  const updateForm = (e: any) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-6 py-32 text-center">
        <h2 className="text-3xl font-serif mb-6">Your bag is empty</h2>
        <Link to="/shop" className="luxury-button">Return to Shop</Link>
      </div>
    );
  }

  return (
    <div className="bg-[#FBFBFB] min-h-screen pt-12 pb-24">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Checkout Flow */}
          <div className="lg:w-2/3">
            <div className="mb-12">
              <h1 className="text-4xl font-serif mb-8">Checkout</h1>
              <div className="flex items-center space-x-4 text-[10px] uppercase tracking-[0.2em]">
                <span className={step >= 1 ? 'text-black font-bold' : 'text-zinc-400'}>Information</span>
                <ChevronRight className="w-3 h-3 text-zinc-300" />
                <span className={step >= 2 ? 'text-black font-bold' : 'text-zinc-400'}>Shipping</span>
                <ChevronRight className="w-3 h-3 text-zinc-300" />
                <span className={step >= 3 ? 'text-black font-bold' : 'text-zinc-400'}>Payment</span>
              </div>
            </div>

            <div className="bg-white border border-zinc-200 p-8 space-y-8">
              {step === 1 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                  <h2 className="text-xl font-serif mb-6">Contact Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <InputField label="First Name" name="firstName" value={formData.firstName} onChange={updateForm} placeholder="Julian" />
                    <InputField label="Last Name" name="lastName" value={formData.lastName} onChange={updateForm} placeholder="Alexander" />
                    <div className="md:col-span-2">
                      <InputField label="Email Address" name="email" value={formData.email} onChange={updateForm} placeholder="julian@example.com" type="email" />
                    </div>
                  </div>
                  <h2 className="text-xl font-serif mb-6 pt-6">Shipping Address</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <InputField label="Address" name="address" value={formData.address} onChange={updateForm} placeholder="123 Luxury Avenue" />
                    </div>
                    <InputField label="City" name="city" value={formData.city} onChange={updateForm} placeholder="Paris" />
                    <InputField label="Postal Code" name="zip" value={formData.zip} onChange={updateForm} placeholder="75001" />
                    <div className="md:col-span-2">
                      <InputField label="Country" name="country" value={formData.country} onChange={updateForm} placeholder="France" />
                    </div>
                  </div>
                  <button 
                    onClick={() => setStep(2)}
                    className="w-full luxury-button mt-8"
                  >
                    Continue to Shipping
                  </button>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                  <h2 className="text-xl font-serif mb-6">Shipping Method</h2>
                  <div className="space-y-4">
                    <ShippingOption 
                      id="standard" 
                      label="Standard Delivery" 
                      time="3-5 Business Days" 
                      price="$25.00" 
                      checked={true}
                    />
                    <ShippingOption 
                      id="express" 
                      label="Express Delivery" 
                      time="1-2 Business Days" 
                      price="$50.00" 
                    />
                  </div>
                  <div className="flex space-x-4 pt-8">
                    <button onClick={() => setStep(1)} className="flex items-center space-x-2 text-xs uppercase tracking-widest text-zinc-500 hover:text-black">
                      <ArrowLeft className="w-3 h-3" />
                      <span>Back</span>
                    </button>
                    <button onClick={() => setStep(3)} className="flex-grow luxury-button">Continue to Payment</button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-serif">Payment Method</h2>
                    <div className="flex items-center space-x-2 text-[10px] uppercase tracking-widest text-zinc-400">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Secure SSL Encryption</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                    <PaymentTab 
                      id="card" 
                      label="Credit Card" 
                      active={paymentMethod === 'card'} 
                      onClick={() => setPaymentMethod('card')} 
                    />
                    <PaymentTab 
                      id="upi" 
                      label="UPI" 
                      active={paymentMethod === 'upi'} 
                      onClick={() => setPaymentMethod('upi')} 
                    />
                    <PaymentTab 
                      id="gpay" 
                      label="Google Pay" 
                      active={paymentMethod === 'gpay'} 
                      onClick={() => setPaymentMethod('gpay')} 
                    />
                    <PaymentTab 
                      id="razorpay" 
                      label="Razorpay" 
                      active={paymentMethod === 'razorpay'} 
                      onClick={() => setPaymentMethod('razorpay')} 
                    />
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="space-y-4 p-6 bg-zinc-50 rounded">
                      <InputField label="Card Number" name="card" value="" onChange={() => {}} placeholder="**** **** **** 1234" />
                      <div className="grid grid-cols-2 gap-4">
                        <InputField label="Expiry Date" name="expiry" value="" onChange={() => {}} placeholder="MM/YY" />
                        <InputField label="CVV" name="cvv" value="" onChange={() => {}} placeholder="***" />
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'upi' && (
                    <div className="space-y-6 p-6 bg-zinc-50 rounded">
                      <p className="text-xs font-bold uppercase tracking-widest text-zinc-500 mb-4">Select UPI App</p>
                      <div className="grid grid-cols-3 gap-4">
                        <UPIButton label="GPay" icon="https://upload.wikimedia.org/wikipedia/commons/b/b2/Google_Pay_Logo.svg" />
                        <UPIButton label="PhonePe" icon="https://upload.wikimedia.org/wikipedia/commons/7/71/PhonePe_Logo.svg" />
                        <UPIButton label="Paytm" icon="https://upload.wikimedia.org/wikipedia/commons/2/24/Paytm_Logo_%28standalone%29.svg" />
                      </div>
                      <div className="pt-4">
                        <InputField label="Enter UPI ID" name="upiId" value="" onChange={() => {}} placeholder="username@upi" />
                      </div>
                    </div>
                  )}

                  {paymentMethod !== 'card' && (
                    <div className="p-12 text-center bg-zinc-50 rounded flex flex-col items-center">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                        <CreditCard className="w-8 h-8 text-zinc-300" />
                      </div>
                      <p className="text-sm text-zinc-500">Redirecting to {paymentMethod.toUpperCase()} secure portal...</p>
                    </div>
                  )}

                  <div className="pt-8 border-t border-zinc-100">
                    <div className="flex items-center space-x-2 text-[10px] text-zinc-400 uppercase tracking-widest mb-6">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Demo Payment Environment - No real charges applied</span>
                    </div>
                    <button 
                      onClick={handlePlaceOrder}
                      className="w-full luxury-button"
                    >
                      Complete Purchase - ${total.toLocaleString()}
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

          {/* Sidebar Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white border border-zinc-200 p-8 sticky top-28">
              <h2 className="text-xl font-serif mb-8">Order Summary</h2>
              <div className="space-y-6 mb-8 max-h-96 overflow-y-auto pr-2">
                {cart.map((item) => (
                  <div key={`${item.id}-${item.selectedSize}`} className="flex space-x-4">
                    <div className="w-16 h-20 bg-zinc-100 flex-shrink-0">
                      <img src={item.images[0]} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-grow">
                      <h4 className="text-xs font-bold uppercase tracking-widest">{item.name}</h4>
                      <p className="text-[10px] text-zinc-400 uppercase mt-1">Size: {item.selectedSize} | Qty: {item.quantity}</p>
                      <p className="text-xs font-bold mt-1">${((item.discountPrice || item.price) * item.quantity).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-4 pt-6 border-t border-zinc-100 text-sm">
                <div className="mb-6">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-400 mb-2 block">Apply Coupon (Try: LUMI200)</label>
                  <div className="flex space-x-2">
                    <input 
                      type="text" 
                      value={coupon}
                      onChange={(e) => setCoupon(e.target.value)}
                      placeholder="Enter code"
                      className="flex-grow bg-zinc-50 border border-zinc-200 px-3 py-2 text-xs focus:outline-none focus:border-black"
                    />
                    <button 
                      onClick={applyCoupon}
                      className="bg-black text-white px-4 py-2 text-[10px] uppercase font-bold"
                    >
                      Apply
                    </button>
                  </div>
                  <p className="mt-2 text-[8px] text-zinc-400 uppercase tracking-widest">Available: LUMI200 - Flat ₹200 OFF</p>
                </div>

                <div className="flex justify-between">
                  <span className="text-zinc-500">Subtotal</span>
                  <span>₹{subtotal.toLocaleString()}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600 font-bold">
                    <span>Coupon Discount</span>
                    <span>-₹{discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-zinc-500">Shipping</span>
                  <span>{shipping === 0 ? 'Complimentary' : `₹${shipping}`}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Tax (GST 12%)</span>
                  <span>₹{tax.toLocaleString()}</span>
                </div>
                <div className="flex justify-between pt-4 border-t border-zinc-100 text-lg font-serif">
                  <span>Total</span>
                  <span>₹{total.toLocaleString()}</span>
                </div>
              </div>

              <AnimatePresence>
                {showCouponPopup && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
                  >
                    <div className="bg-white p-8 max-w-sm w-full text-center shadow-2xl">
                      <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-8 h-8 text-green-500" />
                      </div>
                      <h2 className="text-2xl font-serif mb-2 uppercase">Congratulations!</h2>
                      <p className="text-zinc-500 text-sm mb-6">Coupon <span className="font-bold text-black">LUMI200</span> applied successfully. You saved ₹200 on this order!</p>
                      <button 
                        onClick={() => setShowCouponPopup(false)}
                        className="w-full luxury-button py-3 text-xs"
                      >
                        Amazing
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="mt-8 space-y-4">
                <div className="flex items-center space-x-3 text-xs text-zinc-500">
                  <Truck className="w-4 h-4" />
                  <span>Expected Delivery: Nov 24 - Nov 26</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InputField = ({ label, name, value, onChange, placeholder, type = 'text' }: { label: string, name: string, value: string, onChange: any, placeholder: string, type?: string }) => (
  <div className="space-y-2">
    <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">{label}</label>
    <input 
      type={type} 
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className="w-full bg-zinc-50 border border-zinc-200 px-4 py-3 text-sm focus:outline-none focus:border-black transition-colors"
    />
  </div>
);

const ShippingOption = ({ id, label, time, price, checked = false }: any) => (
  <label className="flex items-center justify-between p-4 border border-zinc-200 hover:border-black cursor-pointer transition-colors">
    <div className="flex items-center space-x-4">
      <input type="radio" name="shipping" id={id} defaultChecked={checked} className="accent-black" />
      <div>
        <p className="text-xs font-bold uppercase tracking-widest">{label}</p>
        <p className="text-[10px] text-zinc-400 mt-1">{time}</p>
      </div>
    </div>
    <span className="text-sm font-bold">{price}</span>
  </label>
);

const PaymentTab = ({ label, active, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`p-4 border text-[10px] uppercase tracking-widest font-bold transition-all ${active ? 'border-black bg-black text-white' : 'border-zinc-200 text-zinc-400 hover:border-zinc-400'}`}
  >
    {label}
  </button>
);

const UPIButton = ({ label, icon }: any) => (
  <button className="flex flex-col items-center justify-center p-4 bg-white border border-zinc-200 hover:border-black transition-colors rounded group">
    <img src={icon} alt={label} className="h-8 mb-2 group-hover:scale-110 transition-transform" />
    <span className="text-[8px] font-bold uppercase tracking-widest text-zinc-400 group-hover:text-black">{label}</span>
  </button>
);

export default Checkout;
