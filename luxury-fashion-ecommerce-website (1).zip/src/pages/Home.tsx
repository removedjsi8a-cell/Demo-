import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import SlidingBanner from '../components/home/SlidingBanner';

const Home = () => {
  const { products } = useShop();

  const sections = [
    { title: "Men's Ethnic Wear", items: products.filter(p => p.category === 'Men').slice(0, 6) },
    { title: "Women's Collection", items: products.filter(p => p.category === 'Women').slice(0, 6) },
    { title: "Trending for Kids", items: products.filter(p => p.category === 'Kids').slice(0, 6) },
    { title: "Best Sellers", items: products.filter(p => p.isBestSeller).slice(0, 6) }
  ];

  return (
    <div className="w-full overflow-x-hidden">
      <SlidingBanner />

      {sections.map((section, sIdx) => (
        <section key={section.title} className={`py-8 ${sIdx % 2 !== 0 ? 'bg-zinc-50' : 'bg-white'}`}>
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg md:text-xl font-serif uppercase tracking-widest border-l-4 border-black pl-3">{section.title}</h2>
              <Link to="/shop" className="text-[9px] uppercase tracking-widest font-bold text-zinc-400 hover:text-black transition-colors">View All</Link>
            </div>

            <div className="grid grid-cols-2 gap-x-3 gap-y-8">
              {section.items.map((product) => (
                <motion.div 
                  key={product.id}
                  className="group"
                >
                  <Link to={`/product/${product.id}`} className="block">
                    <div className="relative aspect-[3/4] overflow-hidden bg-zinc-100 mb-2 shadow-sm rounded-sm">
                      <img 
                        src={product.images[0]} 
                        alt={product.name} 
                        className="w-full h-full object-cover" 
                      />
                      <div className="absolute top-2 left-2 flex flex-col gap-1">
                        {product.isNew && (
                          <span className="bg-black text-white px-2 py-0.5 text-[6px] uppercase tracking-widest font-bold">New</span>
                        )}
                        {product.discountPrice && (
                          <span className="bg-accent text-white px-2 py-0.5 text-[6px] uppercase tracking-widest font-bold">Sale</span>
                        )}
                      </div>
                    </div>
                    <div className="text-center px-1">
                      <h3 className="text-[9px] font-medium uppercase mb-0.5 line-clamp-1">{product.name}</h3>
                      <div className="flex items-center justify-center space-x-2">
                        <span className="text-[11px] font-bold text-black">₹{product.discountPrice?.toLocaleString() || product.price.toLocaleString()}</span>
                        {product.discountPrice && (
                          <span className="text-[9px] text-zinc-400 line-through font-medium">₹{product.price.toLocaleString()}</span>
                        )}
                      </div>
                      <p className="text-[7px] text-green-600 font-bold uppercase tracking-tighter mt-0.5">
                        Save ₹{(product.price - (product.discountPrice || product.price)).toLocaleString()}
                      </p>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      ))}

      <div className="py-12 text-center">
        <Link to="/shop" className="luxury-button text-[9px] uppercase tracking-widest px-10 py-3">
          Explore Entire Collection
        </Link>
      </div>

      {/* Brand Story */}
      <section className="py-24 bg-black text-white overflow-hidden relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 1 }}
              >
                <h2 className="text-5xl md:text-7xl font-serif mb-8 leading-tight">
                  Born in Florence, <br />
                  <span className="italic">Refined in Paris.</span>
                </h2>
                <p className="text-zinc-400 leading-relaxed mb-8 max-w-lg">
                  Every LUMIÈRE piece is a testament to the pursuit of perfection. From the selection of the finest Tuscan leathers to the final stitch in our Parisian atelier, we honor the traditions of haute couture while embracing the future of innovation.
                </p>
                <Link to="/about" className="inline-flex items-center space-x-3 text-sm uppercase tracking-[0.3em] hover:text-accent transition-colors group">
                  <span>Our Heritage</span>
                  <div className="w-8 h-[1px] bg-white group-hover:w-12 group-hover:bg-accent transition-all" />
                </Link>
              </motion.div>
            </div>
            <div className="lg:w-1/2 relative">
              <div className="relative z-10 w-full aspect-square md:aspect-video overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80&w=1000" 
                  alt="Atelier" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -top-12 -right-12 w-64 h-64 border border-zinc-800 hidden lg:block" />
              <div className="absolute -bottom-12 -left-12 w-64 h-64 border border-zinc-800 hidden lg:block" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
