import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const OrderSuccess = () => {
  const [order, setOrder] = React.useState<any>(null);

  React.useEffect(() => {
    const savedOrder = sessionStorage.getItem('lastOrder');
    if (savedOrder) {
      setOrder(JSON.parse(savedOrder));
    }
  }, []);

  if (!order) return <div className="py-20 text-center">Order not found.</div>;

  return (
    <div className="min-h-screen bg-white flex items-center justify-center py-24 px-6">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', damping: 15 }}
            className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-8"
          >
            <CheckCircle className="w-10 h-10 text-green-500" />
          </motion.div>
          
          <h1 className="text-4xl font-serif mb-4 uppercase tracking-widest">Order Confirmed</h1>
          <p className="text-zinc-500 mb-2">Thank you, {order.customer.firstName}. Your order has been placed.</p>
          <p className="text-sm font-bold uppercase tracking-widest text-accent">Order ID: {order.id}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-zinc-50 p-8">
            <h3 className="text-[10px] uppercase tracking-widest font-bold mb-6 border-b border-zinc-200 pb-2">Order Details</h3>
            <div className="space-y-4">
              {order.items.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between text-sm">
                  <span className="text-zinc-500">{item.name} x {item.quantity}</span>
                  <span className="font-medium">${(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
              <div className="pt-4 border-t border-zinc-200 flex justify-between font-bold">
                <span>Total Amount Paid</span>
                <span>${order.total.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="bg-zinc-50 p-8">
            <h3 className="text-[10px] uppercase tracking-widest font-bold mb-6 border-b border-zinc-200 pb-2">Shipping To</h3>
            <div className="text-sm space-y-2 text-zinc-600 leading-relaxed">
              <p className="font-bold text-black">{order.customer.firstName} {order.customer.lastName}</p>
              <p>{order.customer.address}</p>
              <p>{order.customer.city}, {order.customer.zip}</p>
              <p>{order.customer.country}</p>
              <div className="mt-6 pt-4 border-t border-zinc-200">
                <p className="text-[10px] uppercase font-bold text-zinc-400">Payment Method</p>
                <p className="uppercase tracking-widest text-xs font-bold mt-1 text-black">{order.paymentMethod}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/account" className="luxury-button text-xs py-4 px-12">Track Order</Link>
          <Link to="/shop" className="luxury-button-outline text-xs py-4 px-12 flex items-center justify-center space-x-2">
            <span>Continue Shopping</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;
