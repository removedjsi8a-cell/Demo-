import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, ShoppingBag, ChevronRight, Star, Truck, ShieldCheck, RotateCcw, Plus, Minus, ArrowLeft, ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';

const ProductDetails = () => {
  const { id } = useParams();
  const { products, addToCart, toggleWishlist, wishlist } = useShop();
  const product = products.find(p => p.id === id);

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'shipping' | 'reviews'>('description');
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  if (!product) return <div className="py-20 text-center">Product not found</div>;

  const isWishlisted = wishlist.some(p => p.id === product.id);

  const handleAddToCart = () => {
    if (!selectedSize || !selectedColor) {
      alert('Please select size and color');
      return;
    }
    addToCart(product, quantity, selectedSize, selectedColor);
  };

  return (
    <div className="bg-white">
      {/* Breadcrumbs */}
      <div className="container mx-auto px-6 py-8">
        <nav className="flex items-center space-x-2 text-[10px] uppercase tracking-widest text-zinc-400">
          <Link to="/" className="hover:text-black transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/shop" className="hover:text-black transition-colors">Shop</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to={`/shop?category=${product.category}`} className="hover:text-black transition-colors">{product.category}</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-black">{product.name}</span>
        </nav>
      </div>

      <div className="container mx-auto px-6 pb-24">
        <div className="flex flex-col lg:flex-row gap-16">
          {/* Image Gallery */}
          <div className="lg:w-3/5">
            {/* Main Image Slider for Mobile/Desktop */}
            <div className="relative aspect-[3/4] bg-zinc-100 overflow-hidden group mb-4">
              <AnimatePresence mode="wait">
                <motion.img
                  key={selectedImage}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  src={product.images[selectedImage]}
                  className="w-full h-full object-cover"
                />
              </AnimatePresence>
              
              <button 
                onClick={() => setSelectedImage((prev) => (prev > 0 ? prev - 1 : product.images.length - 1))}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full shadow-md z-10"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setSelectedImage((prev) => (prev + 1) % product.images.length)}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full shadow-md z-10"
              >
                <ArrowRight className="w-5 h-5" />
              </button>

              <button 
                onClick={() => toggleWishlist(product)}
                className={`absolute top-4 right-4 p-3 rounded-full bg-white shadow-lg z-10 transition-all ${isWishlisted ? 'text-red-500' : 'text-zinc-400'}`}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Thumbnail Row */}
            <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`w-20 h-24 flex-shrink-0 bg-zinc-100 overflow-hidden border-2 transition-all ${selectedImage === idx ? 'border-black' : 'border-transparent'}`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="lg:w-2/5">
            <div className="mb-4">
              <span className="text-[9px] uppercase tracking-[0.1em] text-zinc-400 mb-1 block">{product.subCategory}</span>
              <h1 className="text-xl font-serif mb-1 uppercase tracking-wider">{product.name}</h1>
              <div className="flex items-center space-x-3 mb-3">
                <div className="flex text-accent">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-2.5 h-2.5 ${i < Math.floor(product.ratings) ? 'fill-current' : ''}`} />
                  ))}
                </div>
                <span className="text-[9px] text-zinc-400 uppercase">({product.ratings} Rating)</span>
              </div>
              <div className="flex items-end space-x-3 bg-zinc-50 p-3 rounded-sm border border-zinc-100">
                <div className="flex flex-col">
                  <span className="text-[10px] uppercase text-zinc-400 font-bold mb-0.5">Offer Price</span>
                  <span className="text-2xl font-serif text-black font-bold leading-none">₹{product.discountPrice?.toLocaleString()}</span>
                </div>
                <div className="flex flex-col border-l border-zinc-200 pl-3">
                  <span className="text-[9px] text-zinc-400 line-through">M.R.P: ₹{product.price.toLocaleString()}</span>
                  <span className="text-[10px] text-green-600 font-bold">₹{product.price - (product.discountPrice || 0)} OFF</span>
                </div>
              </div>
            </div>

            <div className="space-y-10 mb-12">
              {/* Color Selector */}
              <div>
                <h4 className="text-[10px] uppercase tracking-widest font-bold mb-4">Select Color: <span className="font-normal text-zinc-500 ml-2">{selectedColor}</span></h4>
                <div className="flex space-x-3">
                  {product.colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color.name)}
                      className={`w-10 h-10 rounded-full border-2 transition-all flex items-center justify-center ${selectedColor === color.name ? 'border-black' : 'border-transparent'}`}
                    >
                      <div className="w-8 h-8 rounded-full border border-zinc-200" style={{ backgroundColor: color.value }} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector */}
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h4 className="text-[10px] uppercase tracking-widest font-bold">Select Size: <span className="font-normal text-zinc-500 ml-2">{selectedSize}</span></h4>
                  <button 
                    onClick={() => setIsSizeGuideOpen(true)}
                    className="text-[10px] uppercase tracking-widest underline text-zinc-400 hover:text-black"
                  >
                    Size Guide
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-3 text-xs uppercase tracking-widest border transition-all ${selectedSize === size ? 'border-black bg-black text-white' : 'border-zinc-200 hover:border-black'}`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity & Add to Cart */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center border border-zinc-200 h-14">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-6 hover:bg-zinc-50"><Minus className="w-4 h-4" /></button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="px-6 hover:bg-zinc-50"><Plus className="w-4 h-4" /></button>
                </div>
                <button 
                  onClick={handleAddToCart}
                  className="flex-grow luxury-button h-14 flex items-center justify-center space-x-3"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>Add to Shopping Bag</span>
                </button>
              </div>
            </div>

            {/* Product Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 py-8 border-y border-zinc-100">
              <div className="flex items-center space-x-3">
                <Truck className="w-5 h-5 text-zinc-400" />
                <span className="text-[10px] uppercase tracking-widest font-medium">Free Express Shipping</span>
              </div>
              <div className="flex items-center space-x-3">
                <ShieldCheck className="w-5 h-5 text-zinc-400" />
                <span className="text-[10px] uppercase tracking-widest font-medium">Authenticity Guaranteed</span>
              </div>
              <div className="flex items-center space-x-3">
                <RotateCcw className="w-5 h-5 text-zinc-400" />
                <span className="text-[10px] uppercase tracking-widest font-medium">30-Day Returns</span>
              </div>
            </div>

            {/* Tabs */}
            <div className="mt-8">
              <div className="flex space-x-6 border-b border-zinc-100 mb-6">
                {['description', 'shipping', 'reviews'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`pb-3 text-[9px] uppercase tracking-[0.2em] font-bold transition-all relative ${activeTab === tab ? 'text-black' : 'text-zinc-400'}`}
                  >
                    {tab}
                    {activeTab === tab && <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-black" />}
                  </button>
                ))}
              </div>
              <div className="text-zinc-500 text-xs leading-relaxed">
                {activeTab === 'description' && (
                  <div className="space-y-3">
                    <p>{product.description}</p>
                    <ul className="list-disc pl-4 space-y-1">
                      <li>Material: Premium Indian Fabric</li>
                      <li>Handcrafted detail work</li>
                      <li>Made in India</li>
                      <li>Dry Clean Only</li>
                    </ul>
                  </div>
                )}
                {activeTab === 'shipping' && (
                  <div className="space-y-3">
                    <p>Free Shipping on orders above ₹399.</p>
                    <p>Delivery time: 3-7 business days across India.</p>
                  </div>
                )}
                {activeTab === 'reviews' && (
                  <div className="py-4 text-center text-[10px] bg-zinc-50 border border-dashed border-zinc-200">
                    <p>No reviews yet.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Size Guide Modal */}
      <AnimatePresence>
        {isSizeGuideOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setIsSizeGuideOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white p-8 max-w-md w-full"
              onClick={e => e.stopPropagation()}
            >
              <h2 className="text-2xl font-serif mb-6">Size Guide</h2>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-zinc-200">
                    <th className="py-2">Size</th>
                    <th className="py-2">Chest (in)</th>
                    <th className="py-2">Waist (in)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-zinc-100"><td className="py-2">S</td><td className="py-2">36-38</td><td className="py-2">30-32</td></tr>
                  <tr className="border-b border-zinc-100"><td className="py-2">M</td><td className="py-2">38-40</td><td className="py-2">32-34</td></tr>
                  <tr className="border-b border-zinc-100"><td className="py-2">L</td><td className="py-2">40-42</td><td className="py-2">34-36</td></tr>
                  <tr className="border-b border-zinc-100"><td className="py-2">XL</td><td className="py-2">42-44</td><td className="py-2">36-38</td></tr>
                </tbody>
              </table>
              <button 
                onClick={() => setIsSizeGuideOpen(false)}
                className="w-full luxury-button mt-8"
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProductDetails;
