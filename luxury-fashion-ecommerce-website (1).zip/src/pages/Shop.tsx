import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, ChevronDown, LayoutGrid, List, Search, X } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Link, useSearchParams } from 'react-router-dom';
import { Category, SubCategory, Product } from '../types';
import QuickView from '../components/shop/QuickView';

const Shop = () => {
  const { products } = useShop();
  const [searchParams, setSearchParams] = useSearchParams();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [sortBy, setSortBy] = useState<'recommended' | 'lowToHigh' | 'highToLow'>('recommended');

  const activeCategory = searchParams.get('category') as Category | null;
  const activeSubCategory = searchParams.get('subCategory') as SubCategory | null;

  const categories: Category[] = ['Men', 'Women', 'Kids', 'Accessories'];
  const subCategories: SubCategory[] = ['T-Shirts', 'Shirts', 'Hoodies', 'Jackets', 'Jeans', 'Cargo Pants', 'Sneakers', 'Bags', 'Belts', 'Watches', 'Baggy Pants', 'Shorts', 'Lowers'];

  const filteredProducts = useMemo(() => {
    let result = products.filter(p => {
      const matchesCategory = !activeCategory || p.category === activeCategory;
      const matchesSubCategory = !activeSubCategory || p.subCategory === activeSubCategory;
      const matchesSearch = !searchQuery || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSubCategory && matchesSearch;
    });

    if (sortBy === 'lowToHigh') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'highToLow') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, activeCategory, activeSubCategory, searchQuery, sortBy]);

  const toggleFilter = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (newParams.get(key) === value) {
      newParams.delete(key);
    } else {
      newParams.set(key, value);
    }
    setSearchParams(newParams);
  };

  const clearFilters = () => {
    setSearchParams(new URLSearchParams());
    setSearchQuery('');
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Shop Header */}
      <div className="bg-zinc-50 py-20 border-b border-zinc-200">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
              <nav className="flex space-x-2 text-[10px] uppercase tracking-widest text-zinc-400 mb-4">
                <Link to="/" className="hover:text-black">Home</Link>
                <span>/</span>
                <span className="text-black">Shop</span>
              </nav>
              <h1 className="text-5xl font-serif">
                {activeCategory ? activeCategory : 'Our Collection'}
              </h1>
            </div>
            <div className="flex items-center space-x-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search collection..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent border-b border-zinc-300 py-2 pl-8 focus:outline-none focus:border-black transition-colors w-64 text-sm"
                />
                <Search className="w-4 h-4 absolute left-0 top-1/2 -translate-y-1/2 text-zinc-400" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Controls */}
        <div className="flex items-center justify-between mb-12 border-b border-zinc-100 pb-6">
          <div className="flex items-center space-x-8">
            <button 
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="flex items-center space-x-2 text-sm uppercase tracking-widest hover:text-accent transition-colors"
            >
              <Filter className="w-4 h-4" />
              <span>{isFilterOpen ? 'Hide Filters' : 'Show Filters'}</span>
            </button>
            <div className="hidden md:flex items-center space-x-4 border-l border-zinc-200 pl-8">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 ${viewMode === 'grid' ? 'text-black' : 'text-zinc-300'}`}
              >
                <LayoutGrid className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 ${viewMode === 'list' ? 'text-black' : 'text-zinc-300'}`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-xs text-zinc-400 uppercase tracking-widest">{filteredProducts.length} Products</span>
            <div className="flex items-center space-x-2 text-sm">
              <span className="text-zinc-400">Sort:</span>
              <select 
                value={sortBy} 
                onChange={(e) => setSortBy(e.target.value as any)}
                className="font-medium bg-transparent focus:outline-none cursor-pointer"
              >
                <option value="recommended">Recommended</option>
                <option value="lowToHigh">Price: Low to High</option>
                <option value="highToLow">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          {/* Sidebar Filters */}
          <AnimatePresence>
            {isFilterOpen && (
              <motion.aside
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="lg:w-64 space-y-10"
              >
                <div>
                  <h4 className="text-[10px] uppercase tracking-[0.2em] font-bold mb-6">Categories</h4>
                  <ul className="space-y-3">
                    {categories.map(cat => (
                      <li key={cat}>
                        <button 
                          onClick={() => toggleFilter('category', cat)}
                          className={`text-sm tracking-wide hover:translate-x-1 transition-all ${activeCategory === cat ? 'font-bold underline' : 'text-zinc-500'}`}
                        >
                          {cat}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase tracking-[0.2em] font-bold mb-6">Sub Categories</h4>
                  <ul className="grid grid-cols-2 lg:grid-cols-1 gap-3">
                    {subCategories.map(sub => (
                      <li key={sub}>
                        <button 
                          onClick={() => toggleFilter('subCategory', sub)}
                          className={`text-sm tracking-wide hover:translate-x-1 transition-all ${activeSubCategory === sub ? 'font-bold underline' : 'text-zinc-500'}`}
                        >
                          {sub}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 border-t border-zinc-100">
                  <button 
                    onClick={clearFilters}
                    className="flex items-center space-x-2 text-xs uppercase tracking-widest text-zinc-400 hover:text-black transition-colors"
                  >
                    <X className="w-3 h-3" />
                    <span>Clear All</span>
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Product Grid */}
          <div className="flex-grow">
            {filteredProducts.length === 0 ? (
              <div className="py-20 text-center">
                <h3 className="text-2xl font-serif mb-4">No products found</h3>
                <p className="text-zinc-500 mb-8">Try adjusting your filters or search query.</p>
                <button onClick={clearFilters} className="luxury-button">Reset All Filters</button>
              </div>
            ) : (
              <div className={viewMode === 'grid' 
                ? "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-16" 
                : "space-y-12"
              }>
                {filteredProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    viewMode={viewMode} 
                    onQuickView={() => setQuickViewProduct(product)} 
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <QuickView product={quickViewProduct} onClose={() => setQuickViewProduct(null)} />
    </div>
  );
};

const ProductCard = ({ product, viewMode, onQuickView }: { product: Product, viewMode: 'grid' | 'list', onQuickView: () => void }) => {
  if (viewMode === 'list') {
    return (
      <motion.div 
        layout
        className="flex gap-8 group"
      >
        <div className="w-64 aspect-[3/4] bg-zinc-100 overflow-hidden">
          <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
        </div>
        <div className="flex-grow flex flex-col py-4">
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className="text-[10px] uppercase tracking-widest text-zinc-400 mb-2 block">{product.subCategory}</span>
              <h3 className="text-2xl font-serif mb-2 group-hover:text-accent transition-colors">{product.name}</h3>
              <p className="text-zinc-500 text-sm max-w-lg mb-6">{product.description}</p>
            </div>
            <div className="text-right">
              {product.discountPrice ? (
                <div className="flex flex-col">
                  <span className="text-zinc-400 line-through text-sm">₹{product.price}</span>
                  <span className="text-xl font-serif text-accent">₹{product.discountPrice}</span>
                </div>
              ) : (
                <span className="text-xl font-serif">₹{product.price}</span>
              )}
            </div>
          </div>
          <div className="mt-auto flex space-x-4">
            <Link to={`/product/${product.id}`} className="luxury-button text-xs">View Details</Link>
            <button className="luxury-button-outline text-xs">Add to Wishlist</button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group"
    >
      <Link to={`/product/${product.id}`} className="block relative aspect-[3/4] overflow-hidden bg-zinc-100 mb-4 max-w-[280px] mx-auto">
        <img 
          src={product.images[0]} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
        />
        {product.images[1] && (
          <img 
            src={product.images[1]} 
            alt={product.name} 
            className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-700" 
          />
        )}
        <div className="absolute top-3 left-3 flex flex-col space-y-2">
          {product.isNew && (
            <span className="bg-white px-2 py-0.5 text-[7px] uppercase tracking-widest font-bold">New</span>
          )}
          {product.discountPrice && (
            <span className="bg-black text-white px-2 py-0.5 text-[7px] uppercase tracking-widest font-bold">Sale</span>
          )}
        </div>
        <button 
          onClick={(e) => {
            e.preventDefault();
            onQuickView();
          }}
          className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md py-3 text-[9px] uppercase tracking-[0.2em] font-bold translate-y-full group-hover:translate-y-0 transition-transform duration-500 hover:bg-black hover:text-white"
        >
          Quick View
        </button>
      </Link>
      <div className="flex justify-between items-start px-2">
        <div>
          <span className="text-[9px] uppercase tracking-widest text-zinc-400 mb-0.5 block">{product.subCategory}</span>
          <Link to={`/product/${product.id}`} className="text-xs font-medium uppercase hover:text-accent transition-colors line-clamp-1">{product.name}</Link>
        </div>
        <div className="text-right">
          {product.discountPrice ? (
            <div className="flex flex-col">
              <span className="text-zinc-400 line-through text-[9px]">₹{product.price}</span>
              <span className="text-xs font-serif font-bold text-accent">₹{product.discountPrice}</span>
            </div>
          ) : (
            <span className="text-xs font-serif font-bold">₹{product.price}</span>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default Shop;
