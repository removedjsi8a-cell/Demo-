import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, ShoppingCart, Package, Users, 
  BarChart3, Settings, Bell, Search, TrendingUp,
  ArrowUpRight, ArrowDownRight, MoreVertical,
  Plus, Download, Filter
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const data = [
  { name: 'Mon', revenue: 4500, orders: 24 },
  { name: 'Tue', revenue: 5200, orders: 30 },
  { name: 'Wed', revenue: 4800, orders: 28 },
  { name: 'Thu', revenue: 6100, orders: 35 },
  { name: 'Fri', revenue: 5900, orders: 32 },
  { name: 'Sat', revenue: 8500, orders: 48 },
  { name: 'Sun', revenue: 7800, orders: 42 },
];

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="flex h-screen bg-[#F8F9FA]">
      {/* Sidebar */}
      <aside className="w-64 bg-black text-white flex flex-col">
        <div className="p-8 border-b border-zinc-800">
          <h1 className="text-xl font-serif tracking-widest">LUMIÈRE</h1>
          <p className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">Management Portal</p>
        </div>

        <nav className="flex-grow p-4 space-y-2">
          <NavItem 
            icon={<LayoutDashboard className="w-4 h-4" />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<ShoppingCart className="w-4 h-4" />} 
            label="Orders" 
            active={activeTab === 'orders'} 
            onClick={() => setActiveTab('orders')} 
          />
          <NavItem 
            icon={<Package className="w-4 h-4" />} 
            label="Products" 
            active={activeTab === 'products'} 
            onClick={() => setActiveTab('products')} 
          />
          <NavItem 
            icon={<Users className="w-4 h-4" />} 
            label="Customers" 
            active={activeTab === 'customers'} 
            onClick={() => setActiveTab('customers')} 
          />
          <NavItem 
            icon={<BarChart3 className="w-4 h-4" />} 
            label="Analytics" 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')} 
          />
        </nav>

        <div className="p-4 border-t border-zinc-800">
          <NavItem 
            icon={<Settings className="w-4 h-4" />} 
            label="Settings" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
          <div className="mt-4 flex items-center p-3 space-x-3">
            <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center">
              <span className="text-[10px] font-bold">AD</span>
            </div>
            <div>
              <p className="text-xs font-bold">Admin User</p>
              <p className="text-[10px] text-zinc-500">Super Admin</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow overflow-y-auto">
        {/* Top Header */}
        <header className="bg-white border-b border-zinc-200 h-20 flex items-center justify-between px-8 sticky top-0 z-10">
          <div className="flex items-center bg-zinc-100 rounded-full px-4 py-2 w-96">
            <Search className="w-4 h-4 text-zinc-400 mr-2" />
            <input 
              type="text" 
              placeholder="Search analytics, orders, products..." 
              className="bg-transparent border-none focus:outline-none text-sm w-full"
            />
          </div>
          <div className="flex items-center space-x-6">
            <button className="relative text-zinc-400 hover:text-black transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <button className="luxury-button py-2 px-4 text-xs flex items-center space-x-2">
              <Plus className="w-4 h-4" />
              <span>Create Product</span>
            </button>
          </div>
        </header>

        {/* Dashboard View */}
        <div className="p-8">
          <div className="mb-8 flex justify-between items-end">
            <div>
              <h2 className="text-3xl font-serif">Aperçu Général</h2>
              <p className="text-zinc-500 text-sm">Welcome back. Here is what's happening today.</p>
            </div>
            <div className="flex space-x-3">
              <button className="flex items-center space-x-2 bg-white border border-zinc-200 px-4 py-2 text-xs font-medium hover:bg-zinc-50">
                <Filter className="w-4 h-4" />
                <span>Filters</span>
              </button>
              <button className="flex items-center space-x-2 bg-white border border-zinc-200 px-4 py-2 text-xs font-medium hover:bg-zinc-50">
                <Download className="w-4 h-4" />
                <span>Export Report</span>
              </button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <StatCard label="Total Revenue" value="$128,430.00" change="+12.5%" trend="up" />
            <StatCard label="Total Orders" value="1,240" change="+8.2%" trend="up" />
            <StatCard label="Total Customers" value="8,540" change="-2.4%" trend="down" />
            <StatCard label="Avg. Order Value" value="$103.50" change="+5.1%" trend="up" />
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
            <div className="lg:col-span-2 bg-white p-6 border border-zinc-200 shadow-sm">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-lg font-serif">Revenue Overview</h3>
                <select className="text-xs border-none bg-zinc-100 px-3 py-1 rounded">
                  <option>Last 7 Days</option>
                  <option>Last 30 Days</option>
                </select>
              </div>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#000" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#000" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#999' }} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#999' }} />
                    <Tooltip />
                    <Area type="monotone" dataKey="revenue" stroke="#000" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 border border-zinc-200 shadow-sm">
              <h3 className="text-lg font-serif mb-8">Best Selling Categories</h3>
              <div className="space-y-6">
                <CategoryProgress label="Women's Wear" percentage={45} color="bg-black" />
                <CategoryProgress label="Men's Wear" percentage={32} color="bg-zinc-600" />
                <CategoryProgress label="Accessories" percentage={18} color="bg-zinc-400" />
                <CategoryProgress label="Limited Edition" percentage={5} color="bg-zinc-200" />
              </div>
              <div className="mt-12 p-4 bg-zinc-50 rounded">
                <div className="flex items-center space-x-3 mb-2">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                  <span className="text-xs font-bold uppercase tracking-widest">Growth Alert</span>
                </div>
                <p className="text-[10px] text-zinc-500 leading-relaxed">
                  Accessories sales have increased by 22% compared to last week. Consider featuring more items on home page.
                </p>
              </div>
            </div>
          </div>

          {/* Recent Orders Table */}
          <div className="bg-white border border-zinc-200 shadow-sm">
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center">
              <h3 className="text-lg font-serif">Recent Orders</h3>
              <button className="text-xs uppercase tracking-widest underline hover:text-zinc-500">View All Orders</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] uppercase tracking-widest text-zinc-400 bg-zinc-50">
                    <th className="px-6 py-4 font-medium">Order ID</th>
                    <th className="px-6 py-4 font-medium">Customer</th>
                    <th className="px-6 py-4 font-medium">Product</th>
                    <th className="px-6 py-4 font-medium">Amount</th>
                    <th className="px-6 py-4 font-medium">Status</th>
                    <th className="px-6 py-4 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100">
                  <OrderRow id="#ORD-8542" customer="Elena Russo" product="Midnight Velvet Blazer" amount="$850.00" status="Processing" />
                  <OrderRow id="#ORD-8541" customer="James Chen" product="Lunar Tech Sneakers" amount="$420.00" status="Shipped" />
                  <OrderRow id="#ORD-8540" customer="Sofia Vergara" product="Silk Drapery Gown" amount="$1,200.00" status="Delivered" />
                  <OrderRow id="#ORD-8539" customer="Marcus Aurelius" product="Cashmere Hoodie" amount="$350.00" status="Delivered" />
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm transition-all ${active ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-white hover:bg-zinc-900'}`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

const StatCard = ({ label, value, change, trend }: { label: string, value: string, change: string, trend: 'up' | 'down' }) => (
  <div className="bg-white p-6 border border-zinc-200 shadow-sm hover:shadow-md transition-shadow">
    <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-400 mb-2 font-bold">{label}</p>
    <div className="flex items-end justify-between">
      <h4 className="text-2xl font-serif">{value}</h4>
      <div className={`flex items-center space-x-1 text-xs font-medium ${trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
        <span>{change}</span>
        {trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
      </div>
    </div>
  </div>
);

const CategoryProgress = ({ label, percentage, color }: { label: string, percentage: number, color: string }) => (
  <div>
    <div className="flex justify-between text-xs mb-2">
      <span className="text-zinc-500">{label}</span>
      <span className="font-bold">{percentage}%</span>
    </div>
    <div className="h-1.5 w-full bg-zinc-100 rounded-full overflow-hidden">
      <div className={`h-full ${color}`} style={{ width: `${percentage}%` }} />
    </div>
  </div>
);

const OrderRow = ({ id, customer, product, amount, status }: { id: string, customer: string, product: string, amount: string, status: string }) => (
  <tr className="hover:bg-zinc-50 transition-colors">
    <td className="px-6 py-4 text-xs font-bold">{id}</td>
    <td className="px-6 py-4 text-xs">{customer}</td>
    <td className="px-6 py-4 text-xs text-zinc-500">{product}</td>
    <td className="px-6 py-4 text-xs font-bold">{amount}</td>
    <td className="px-6 py-4 text-xs">
      <span className={`px-2 py-1 rounded-full text-[8px] uppercase tracking-widest font-bold ${
        status === 'Processing' ? 'bg-amber-50 text-amber-600' : 
        status === 'Shipped' ? 'bg-blue-50 text-blue-600' : 
        'bg-green-50 text-green-600'
      }`}>
        {status}
      </span>
    </td>
    <td className="px-6 py-4">
      <button className="text-zinc-400 hover:text-black">
        <MoreVertical className="w-4 h-4" />
      </button>
    </td>
  </tr>
);

export default AdminDashboard;
