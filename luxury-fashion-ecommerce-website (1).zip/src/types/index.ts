export type Category = 'Men' | 'Women' | 'Kids' | 'Accessories' | 'New Arrivals' | 'Best Sellers' | 'Collections';
export type SubCategory = 'T-Shirts' | 'Shirts' | 'Hoodies' | 'Jackets' | 'Jeans' | 'Cargo Pants' | 'Sneakers' | 'Bags' | 'Belts' | 'Watches' | 'Shorts' | 'Lowers' | 'Baggy Pants';

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  images: string[];
  category: Category;
  subCategory: SubCategory;
  ratings: number;
  reviews: Review[];
  stockStatus: 'In Stock' | 'Low Stock' | 'Out of Stock';
  sizes: string[];
  colors: { name: string; value: string }[];
  isNew?: boolean;
  isBestSeller?: boolean;
  isTrending?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface Order {
  id: string;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  total: number;
  items: CartItem[];
  shippingAddress: string;
  customerName: string;
  customerEmail: string;
  paymentMethod: string;
}

export interface User {
  name: string;
  email: string;
  avatar: string;
  loyaltyPoints: number;
  orders: Order[];
}
